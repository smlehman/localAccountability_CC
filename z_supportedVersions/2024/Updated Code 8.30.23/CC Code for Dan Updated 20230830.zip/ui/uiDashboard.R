##################### Tab1 -dashboard #######################
uiDashboard <- tabPanel("",
                         icon = icon("fas fa-home"),
                        title = "Home",
                         value = "Home",
                        
                        #------------------------------------------------------------------------------------#
                        # dashboard content ####
                        #------------------------------------------------------------------------------------#              
        div(
                              "This is where stuff goes"
        )

)#end tab1
